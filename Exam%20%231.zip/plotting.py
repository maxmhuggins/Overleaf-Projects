#Plotting Test data
#max huggins
#2/17/19

import matplotlib.pyplot as plt
import numpy as np

R_1 = 100
R_2 = 100

#define data arrays
time_data = []
voltage_data = []

#read in data
lines = np.loadtxt('Test_1.txt', delimiter=',')
for line in lines:
    time_data.append(line[0] / 3600)
    v_in = ((R_1 + R_2) / (R_1)) * line[1]
    voltage_data.append(v_in)

#make plot
fig = plt.figure()
ax = fig.add_subplot(1,1,1)

#make an xy scatter plot
plt.scatter(time_data,voltage_data,color='r', label = 'data')

#label axes
ax.set_xlabel('Time (hr)')
ax.set_ylabel('Voltage (V)')
ax.set_title('Battery Discharge')
plt.legend(loc = 'best')

#save it
plt.savefig('TestData_1.png')

